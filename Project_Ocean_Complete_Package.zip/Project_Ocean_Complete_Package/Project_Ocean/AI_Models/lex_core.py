# Core logic for Lex AI

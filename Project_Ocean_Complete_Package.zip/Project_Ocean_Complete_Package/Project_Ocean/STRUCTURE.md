# Project Ocean Structure

This file describes the directory organization.